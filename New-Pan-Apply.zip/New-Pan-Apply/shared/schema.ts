import { pgTable, text, serial, date, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Address schema for employees
export const addressSchema = z.object({
  addressType: z.enum(["urban", "rural"]),
  // Urban fields
  houseNo: z.string().optional(),
  area: z.string().optional(),
  locality: z.string().optional(),
  city: z.string().optional(),
  // Rural fields
  village: z.string().optional(),
  postOffice: z.string().optional(),
  tehsil: z.string().optional(),
  district: z.string().optional(),
  // Common fields
  street: z.string().optional(),
  state: z.string().optional(),
  zipCode: z.string().optional(),
});

// Emergency contact schema
export const emergencyContactSchema = z.object({
  name: z.string().optional(),
  relationship: z.string().optional(),
  phoneNumber: z.string().optional(),
});

// Employee table
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  title: text("title").notNull().default("Shri"),
  fullName: text("full_name").notNull(),
  relationship: text("relationship").notNull().default("none"),
  fatherName: text("father_name"),
  motherName: text("mother_name"),
  childName: text("child_name"),
  email: text("email").notNull().unique(),
  phoneNumber: text("phone_number").notNull(),
  dateOfBirth: date("date_of_birth").notNull(),
  gender: text("gender"),
  // Citizenship info
  residencyStatus: text("residency_status").default("indian_citizen"),
  nationality: text("nationality").default("Indian"),
  // Indian ID documents
  aadhaarNumber: text("aadhaar_number"),
  panNumber: text("pan_number"),
  // NRI specific fields
  passportNumber: text("passport_number"),
  countryOfResidence: text("country_of_residence"),
  overseasAddress: text("overseas_address"),
  address: jsonb("address").notNull(),
  emergencyContact: jsonb("emergency_contact"),
  // Document references
  idProofFilename: text("id_proof_filename"),
  photoFilename: text("photo_filename"),
  signature: text("signature"),
  // Application status
  status: text("status").default("draft").notNull(), // Statuses: draft, pending, approved, rejected
  isPaid: boolean("is_paid").default(false).notNull(), // Payment status
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Employee schema
export const employeeSchema = createInsertSchema(employees, {
  fullName: (schema) => schema.min(1, "Full name is required"),
  email: (schema) => schema.email("Please enter a valid email address"),
  phoneNumber: (schema) => schema.min(10, "Please enter a valid phone number"),
});

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = typeof employees.$inferInsert;

// Custom schemas for frontend validation
export const personalInfoSchema = z.object({
  title: z.enum(["Shri", "Smt", "Kumari", "Miss"]).default("Shri"),
  fullName: z.string().min(1, "Full name as it should appear on PAN card is required"),
  relationship: z.enum(["none", "S/O", "D/O", "C/O", "W/O"]).default("none"),
  parentNameChoice: z.enum(["none", "father", "mother", "guardian"]).default("none"),
  fatherName: z.string().optional(),
  motherName: z.string().optional(),
  guardianName: z.string().optional(),
  email: z.string().email("Please enter a valid email address"),
  phoneNumber: z.string().min(10, "Please enter a valid phone number"),
  dateOfBirth: z.string().refine(
    (val) => {
      const date = new Date(val);
      return !isNaN(date.getTime());
    },
    { message: "Please enter a valid date" }
  ),
  gender: z.string().optional(),
  // Citizenship info
  residencyStatus: z.enum(["none", "indian_citizen", "nri"]).default("none"),
  nationality: z.string().optional(),
  // Indian ID documents
  aadhaarNumber: z.string().optional(),
  panNumber: z.string().optional(),
  // NRI specific fields
  passportNumber: z.string().optional(),
  countryOfResidence: z.string().optional(),
  overseasAddress: z.string().optional(),
  // Address and contacts
  address: addressSchema.extend({
    addressType: z.enum(["none", "urban", "rural"]).default("none"),
  }),
  emergencyContact: emergencyContactSchema,

  // Document info - the actual files will be handled separately
  idProofFilename: z.string().optional(),
  photoFilename: z.string().optional(),
  signature: z.string().optional(), // Base64 encoded signature image
});

export type PersonalInfo = z.infer<typeof personalInfoSchema>;
