import { db } from "./index";
import { employees } from "@shared/schema";

async function seed() {
  try {
    console.log("🌱 Seeding database...");
    
    // Check if there are any existing employees to avoid duplicates
    const existingEmployees = await db.query.employees.findMany();
    
    if (existingEmployees.length > 0) {
      console.log("Database already has employee data. Skipping seed.");
      return;
    }
    
    // Sample employee data
    const sampleEmployees = [
      {
        firstName: "John",
        lastName: "Doe",
        email: "john.doe@example.com",
        phoneNumber: "(555) 123-4567",
        dateOfBirth: new Date("1990-05-15"),
        gender: "male",
        address: {
          street: "123 Main Street",
          city: "New York",
          state: "NY",
          zipCode: "10001"
        },
        emergencyContact: {
          name: "Jane Doe",
          relationship: "Spouse",
          phone: "(555) 987-6543"
        },
        status: "pending",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        firstName: "Sarah",
        lastName: "Johnson",
        email: "sarah.johnson@example.com",
        phoneNumber: "(555) 234-5678",
        dateOfBirth: new Date("1985-08-22"),
        gender: "female",
        address: {
          street: "456 Park Avenue",
          city: "Boston",
          state: "MA",
          zipCode: "02108"
        },
        emergencyContact: {
          name: "Michael Johnson",
          relationship: "Brother",
          phone: "(555) 876-5432"
        },
        status: "pending",
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
    
    // Insert sample employees
    await db.insert(employees).values(sampleEmployees);
    
    console.log("✅ Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
