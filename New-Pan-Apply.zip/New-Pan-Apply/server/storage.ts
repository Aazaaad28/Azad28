import { db } from "@db";
import { employees, type InsertEmployee } from "@shared/schema";
import { eq } from "drizzle-orm";

export const storage = {
  // Employee methods
  async getEmployees() {
    return await db.query.employees.findMany({
      orderBy: (employees, { desc }) => [desc(employees.createdAt)],
    });
  },

  async getEmployeeById(id: number) {
    return await db.query.employees.findFirst({
      where: eq(employees.id, id),
    });
  },

  async getEmployeeByEmail(email: string) {
    return await db.query.employees.findFirst({
      where: eq(employees.email, email),
    });
  },

  async createEmployee(data: InsertEmployee) {
    const [employee] = await db.insert(employees).values(data).returning();
    return employee;
  },

  async updateEmployee(id: number, data: Partial<InsertEmployee>) {
    const [employee] = await db
      .update(employees)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(employees.id, id))
      .returning();
    return employee;
  },

  async deleteEmployee(id: number) {
    const [employee] = await db
      .delete(employees)
      .where(eq(employees.id, id))
      .returning();
    return employee;
  },
};
