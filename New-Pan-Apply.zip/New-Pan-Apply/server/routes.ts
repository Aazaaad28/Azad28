import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { personalInfoSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import Razorpay from "razorpay";
import crypto from "crypto";

// Initialize Razorpay
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || '',
  key_secret: process.env.RAZORPAY_KEY_SECRET || ''
});

// Fixed price for PAN application (in INR)
const PAN_APPLICATION_FEE = 19900; // ₹199.00 (amount in paise)

export async function registerRoutes(app: Express): Promise<Server> {
  // Employee API routes
  app.get("/api/employees", async (req, res) => {
    try {
      const employees = await storage.getEmployees();
      return res.json(employees);
    } catch (error) {
      console.error("Error fetching employees:", error);
      return res.status(500).json({ error: "Failed to fetch employees" });
    }
  });

  app.get("/api/employees/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid employee ID" });
      }

      const employee = await storage.getEmployeeById(id);
      if (!employee) {
        return res.status(404).json({ error: "Employee not found" });
      }

      return res.json(employee);
    } catch (error) {
      console.error("Error fetching employee:", error);
      return res.status(500).json({ error: "Failed to fetch employee" });
    }
  });

  app.post("/api/employees", async (req, res) => {
    try {
      // Validate request body
      const validatedData = personalInfoSchema.parse(req.body);
      
      // Check if email already exists
      const existingEmployee = await storage.getEmployeeByEmail(validatedData.email);
      if (existingEmployee) {
        return res.status(409).json({ error: "Email already exists" });
      }

      // Process and transform the data for database storage
      const employeeData = {
        title: validatedData.title,
        fullName: validatedData.fullName,
        relationship: validatedData.relationship,
        fatherName: validatedData.fatherName,
        motherName: validatedData.motherName,
        email: validatedData.email,
        phoneNumber: validatedData.phoneNumber,
        dateOfBirth: validatedData.dateOfBirth, // Already validated as a string in schema
        gender: validatedData.gender,
        residencyStatus: validatedData.residencyStatus === "none" ? null : validatedData.residencyStatus,
        nationality: validatedData.nationality,
        aadhaarNumber: validatedData.aadhaarNumber,
        panNumber: validatedData.panNumber,
        passportNumber: validatedData.passportNumber,
        countryOfResidence: validatedData.countryOfResidence,
        overseasAddress: validatedData.overseasAddress,
        address: validatedData.address,
        emergencyContact: validatedData.emergencyContact,
        status: "pending",
        isPaid: true, // This is a completed application
        // Add document fields
        idProofFilename: validatedData.idProofFilename,
        photoFilename: validatedData.photoFilename,
        signature: validatedData.signature
      };

      // Create employee
      const newEmployee = await storage.createEmployee(employeeData);
      return res.status(201).json(newEmployee);
    } catch (error) {
      console.error("Error creating employee:", error);
      
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      
      return res.status(500).json({ error: "Failed to create employee" });
    }
  });
  
  // Save application as draft
  app.post("/api/save-draft", async (req, res) => {
    try {
      // We will allow partial data for draft applications
      const data = req.body;
      
      // Check if user has an existing draft
      let existingDraft = null;
      if (data.email) {
        existingDraft = await storage.getEmployeeByEmail(data.email);
      }
      
      // Format data for storage
      const draftData = {
        title: data.title || "Shri",
        fullName: data.fullName || "",
        relationship: data.relationship || "S/O",
        fatherName: data.fatherName,
        motherName: data.motherName,
        email: data.email || "", // Will be validated on final submission
        phoneNumber: data.phoneNumber || "",
        dateOfBirth: data.dateOfBirth || null,
        gender: data.gender,
        residencyStatus: data.residencyStatus === "none" ? null : data.residencyStatus,
        nationality: data.nationality,
        aadhaarNumber: data.aadhaarNumber,
        panNumber: data.panNumber,
        passportNumber: data.passportNumber,
        countryOfResidence: data.countryOfResidence,
        overseasAddress: data.overseasAddress,
        address: data.address || {},
        emergencyContact: data.emergencyContact || {},
        status: "draft",
        isPaid: false,
        idProofFilename: data.idProofFilename,
        photoFilename: data.photoFilename,
        signature: data.signature
      };
      
      let result;
      if (existingDraft && existingDraft.status === "draft") {
        // Update existing draft
        result = await storage.updateEmployee(existingDraft.id, {
          ...draftData,
          updatedAt: new Date()
        });
      } else {
        // Create new draft
        result = await storage.createEmployee(draftData);
      }
      
      return res.status(200).json({
        success: true,
        message: "Application draft saved successfully",
        data: result
      });
    } catch (error) {
      console.error("Error saving draft:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to save application draft",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });
  
  // Get draft application by email
  app.get("/api/drafts/:email", async (req, res) => {
    try {
      const email = req.params.email;
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      
      const draft = await storage.getEmployeeByEmail(email);
      if (!draft || draft.status !== "draft") {
        return res.status(404).json({ error: "No draft application found" });
      }
      
      return res.status(200).json(draft);
    } catch (error) {
      console.error("Error fetching draft:", error);
      return res.status(500).json({ error: "Failed to fetch draft application" });
    }
  });

  app.patch("/api/employees/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid employee ID" });
      }

      // Check if employee exists
      const existingEmployee = await storage.getEmployeeById(id);
      if (!existingEmployee) {
        return res.status(404).json({ error: "Employee not found" });
      }

      // Update employee
      const updatedEmployee = await storage.updateEmployee(id, req.body);
      return res.json(updatedEmployee);
    } catch (error) {
      console.error("Error updating employee:", error);
      return res.status(500).json({ error: "Failed to update employee" });
    }
  });

  // Payment routes
  app.post("/api/create-payment", async (req: Request, res: Response) => {
    try {
      // Create a unique receipt ID - timestamp + random string
      const receiptId = `rcpt_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
      
      // Create Razorpay order
      const options = {
        amount: PAN_APPLICATION_FEE,
        currency: "INR",
        receipt: receiptId,
        payment_capture: 1, // Auto-capture payment
        notes: {
          applicationType: "PAN Application"
        }
      };
      
      const order = await razorpay.orders.create(options);
      
      // Return order details and Razorpay key ID to frontend
      res.json({
        orderId: order.id,
        amount: order.amount,
        currency: order.currency,
        keyId: process.env.RAZORPAY_KEY_ID
      });
    } catch (error) {
      console.error("Razorpay order creation failed:", error);
      res.status(500).json({ error: "Payment initialization failed" });
    }
  });
  
  // Verify Razorpay payment signature
  app.post("/api/verify-payment", (req: Request, res: Response) => {
    try {
      const {
        razorpay_order_id,
        razorpay_payment_id,
        razorpay_signature
      } = req.body;
      
      // Create signature verification string
      const body = razorpay_order_id + "|" + razorpay_payment_id;
      
      // Verify signature using Razorpay's verify method
      const expectedSignature = crypto
        .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || '')
        .update(body.toString())
        .digest('hex');
      
      // Compare signatures
      const isAuthentic = expectedSignature === razorpay_signature;
      
      if (isAuthentic) {
        res.json({ status: "success", payment_id: razorpay_payment_id });
      } else {
        res.status(400).json({ status: "failure", error: "Payment verification failed" });
      }
    } catch (error) {
      console.error("Payment verification failed:", error);
      res.status(500).json({ status: "error", error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
