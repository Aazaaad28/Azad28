import React, { useEffect, useState } from 'react';

interface RazorpayScriptProps {
  children: React.ReactNode;
}

export function RazorpayScript({ children }: RazorpayScriptProps) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    // Check if Razorpay is already loaded
    if (window.Razorpay) {
      setLoaded(true);
      return;
    }

    // Load Razorpay script
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    script.onload = () => {
      setLoaded(true);
    };
    script.onerror = () => {
      setError(true);
    };

    document.body.appendChild(script);

    return () => {
      // Cleanup script on unmount
      document.body.removeChild(script);
    };
  }, []);

  if (error) {
    return (
      <div className="p-4 bg-red-50 text-red-700 rounded-md">
        Failed to load payment gateway. Please refresh the page or try again later.
      </div>
    );
  }

  if (!loaded) {
    return (
      <div className="flex items-center justify-center p-6">
        <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
        <span className="ml-3 text-gray-600">Loading payment gateway...</span>
      </div>
    );
  }

  return <>{children}</>;
}

// Add window.Razorpay to the global Window interface
declare global {
  interface Window {
    Razorpay: any;
  }
}
