import React, { useEffect, useState } from 'react';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowRight, CreditCard, QrCode, Smartphone } from "lucide-react";

// Price display constants
const DISPLAY_AMOUNT = "₹180.00";
const DISPLAY_TAX = "₹19.00";
const DISPLAY_TOTAL = "₹199.00";

interface PaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
}

export function PaymentModal({ open, onOpenChange, onSuccess, customerName, customerEmail, customerPhone }: PaymentModalProps) {
  const { toast } = useToast();
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'qr'>('card');
  const [isLoading, setIsLoading] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardName, setCardName] = useState('');
  const [upiId, setUpiId] = useState('');
  const [qrScanned, setQrScanned] = useState(false);

  // Initialize Razorpay order on component mount
  useEffect(() => {
    if (open) {
      initializePayment();
    }
  }, [open]);

  // Create Razorpay order
  const initializePayment = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/create-payment', {});
      const data = await response.json();
      setOrderId(data.orderId);
      setIsLoading(false);
    } catch (error) {
      console.error('Payment initialization failed:', error);
      toast({
        title: 'Error',
        description: 'Failed to initialize payment. Please try again.',
        variant: 'destructive',
      });
      setIsLoading(false);
    }
  };

  // Format card number with spaces
  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };

  // Format card expiry with slash
  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    
    if (v.length >= 2) {
      return `${v.substring(0, 2)}/${v.substring(2)}`;
    }
    
    return v;
  };

  // Process the payment
  const processPayment = () => {
    if (!orderId) {
      toast({
        title: 'Error',
        description: 'Payment initialization failed. Please try again.',
        variant: 'destructive',
      });
      return;
    }

    const options = {
      key: import.meta.env.VITE_RAZORPAY_KEY_ID || '', // Use Razorpay Key ID
      order_id: orderId,
      amount: 19900, // 199 INR in paise
      currency: 'INR',
      name: 'PAN Card Application',
      description: 'PAN Card Application Fee',
      image: 'https://example.com/your_logo',
      prefill: {
        name: customerName,
        email: customerEmail,
        contact: customerPhone,
        method: undefined as any,
      },
      notes: {
        address: 'PAN Card Application Portal'
      },
      theme: {
        color: '#3399cc'
      },
      // This handler is called when payment succeeds
      handler: function (response: any) {
        verifyPayment(response.razorpay_payment_id, response.razorpay_order_id, response.razorpay_signature);
      },
      modal: {
        // We'll customize the option based on chosen payment method
        ondismiss: function() {
          toast({
            title: 'Payment Cancelled',
            description: 'You have cancelled the payment process.',
            variant: 'destructive',
          });
        }
      }
    };

    // Set payment method preference for Razorpay
    if (paymentMethod === 'card') {
      // Credit/debit card preference
      options.prefill.method = 'card';
    } else if (paymentMethod === 'upi') {
      // UPI preference
      options.prefill.method = 'upi';
    } else if (paymentMethod === 'qr') {
      // QR code preference
      options.prefill.method = 'upi';
    }

    // Initialize Razorpay checkout
    const razorpay = new (window as any).Razorpay(options);
    razorpay.open();
  };

  // Verify the payment with your backend
  const verifyPayment = async (paymentId: string, orderId: string, signature: string) => {
    try {
      const response = await apiRequest('POST', '/api/verify-payment', {
        razorpay_payment_id: paymentId,
        razorpay_order_id: orderId,
        razorpay_signature: signature,
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        toast({
          title: 'Payment Successful',
          description: 'Your payment has been processed successfully.',
        });
        onSuccess();
        onOpenChange(false);
      } else {
        toast({
          title: 'Payment Failed',
          description: 'Payment verification failed. Please try again.',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Payment verification failed:', error);
      toast({
        title: 'Error',
        description: 'Failed to verify payment. Please contact support.',
        variant: 'destructive',
      });
    }
  };

  // Payment tabs based on payment method
  const renderPaymentTabs = () => {
    return (
      <Tabs defaultValue="card" onValueChange={(value) => setPaymentMethod(value as 'card' | 'upi' | 'qr')}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="card" className="flex items-center justify-center">
            <CreditCard className="mr-2 h-4 w-4" />
            Card
          </TabsTrigger>
          <TabsTrigger value="upi" className="flex items-center justify-center">
            <Smartphone className="mr-2 h-4 w-4" />
            UPI
          </TabsTrigger>
          <TabsTrigger value="qr" className="flex items-center justify-center">
            <QrCode className="mr-2 h-4 w-4" />
            QR Code
          </TabsTrigger>
        </TabsList>

        <TabsContent value="card" className="space-y-4 mt-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="card-number">Card Number</Label>
              <Input
                id="card-number"
                placeholder="4111 1111 1111 1111"
                value={cardNumber}
                onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                maxLength={19}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="expiry">Expiry Date</Label>
                <Input
                  id="expiry"
                  placeholder="MM/YY"
                  value={cardExpiry}
                  onChange={(e) => setCardExpiry(formatExpiry(e.target.value))}
                  maxLength={5}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cvv">CVV</Label>
                <Input
                  id="cvv"
                  placeholder="123"
                  value={cardCvv}
                  onChange={(e) => setCardCvv(e.target.value.replace(/[^0-9]/g, ''))}
                  maxLength={3}
                  type="password"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="name-on-card">Name on Card</Label>
              <Input
                id="name-on-card"
                placeholder="John Doe"
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="upi" className="space-y-4 mt-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="upi-id">UPI ID</Label>
              <Input
                id="upi-id"
                placeholder="yourname@upi"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
              />
            </div>
            <div className="bg-blue-50 p-4 rounded-md">
              <p className="text-sm text-blue-800">
                <strong>Popular UPI options:</strong> Google Pay, PhonePe, Paytm, BHIM UPI
              </p>
            </div>
            <RadioGroup defaultValue="googlepay">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="googlepay" id="googlepay" />
                <Label htmlFor="googlepay" className="flex items-center">
                  <span className="font-medium">Google Pay</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="phonepe" id="phonepe" />
                <Label htmlFor="phonepe" className="flex items-center">
                  <span className="font-medium">PhonePe</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="paytm" id="paytm" />
                <Label htmlFor="paytm" className="flex items-center">
                  <span className="font-medium">Paytm</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="bhim" id="bhim" />
                <Label htmlFor="bhim" className="flex items-center">
                  <span className="font-medium">BHIM UPI</span>
                </Label>
              </div>
            </RadioGroup>
          </div>
        </TabsContent>

        <TabsContent value="qr" className="space-y-4 mt-4">
          <div className="flex flex-col items-center justify-center space-y-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 w-full max-w-[240px] h-[240px] flex items-center justify-center">
              {qrScanned ? (
                <div className="text-center">
                  <div className="h-16 w-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="h-8 w-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-green-700 font-medium">QR Code Scanned!</p>
                </div>
              ) : (
                <div className="text-center">
                  <QrCode size={100} className="mx-auto text-gray-400" />
                  <p className="text-sm text-gray-500 mt-2">QR Code will appear in Razorpay checkout</p>
                </div>
              )}
            </div>
            <p className="text-sm text-center max-w-[280px]">
              Scan with any UPI app including Google Pay, PhonePe, Paytm, or BHIM UPI
            </p>
          </div>
        </TabsContent>
      </Tabs>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] p-0 overflow-hidden">
        <DialogHeader className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-6">
          <DialogTitle className="text-xl font-bold flex items-center">
            <span className="bg-white text-blue-700 h-8 w-8 rounded-full flex items-center justify-center mr-3 shadow-md">
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </span>
            Payment for PAN Application
          </DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          {/* Payment Summary */}
          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <h3 className="font-medium text-gray-900 mb-2">Payment Summary</h3>
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">PAN Card Application Fee</span>
                <span className="text-gray-900">{DISPLAY_AMOUNT}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Tax</span>
                <span className="text-gray-900">{DISPLAY_TAX}</span>
              </div>
              <div className="border-t border-gray-300 my-2 pt-2 flex justify-between">
                <span className="font-medium">Total</span>
                <span className="font-medium">{DISPLAY_TOTAL}</span>
              </div>
            </div>
          </div>
          
          {/* Payment Methods */}
          {renderPaymentTabs()}
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isLoading}>
            Cancel
          </Button>
          <Button 
            onClick={processPayment} 
            disabled={isLoading}
            className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
          >
            {isLoading ? 'Processing...' : 'Pay Now'}
            {!isLoading && <ArrowRight className="ml-2 h-4 w-4" />}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
