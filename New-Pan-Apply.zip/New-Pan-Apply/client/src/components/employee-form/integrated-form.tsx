import { useState, useRef } from "react";
import SignatureCanvas from "react-signature-canvas";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { personalInfoSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { PaymentModal } from "@/components/payment/payment-modal";
import { RazorpayScript } from "@/components/payment/razorpay-script";
import { formatPhoneNumber } from "@/lib/utils";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ArrowRight, Mail, Phone, Calendar as CalendarIcon, Briefcase, Building, DollarSign, CreditCard, Smartphone, QrCode } from "lucide-react";

type PersonalInfoValues = z.infer<typeof personalInfoSchema>;

interface IntegratedFormProps {
  onComplete: () => void;
  isSubmitted: boolean;
}

export default function IntegratedForm({ onComplete, isSubmitted }: IntegratedFormProps) {
  const { toast } = useToast();
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const signatureRef = useRef<SignatureCanvas>(null);
  const [uploadedFiles, setUploadedFiles] = useState<{
    idProof: File | null;
    photo: File | null;
    signature: File | null;
  }>({
    idProof: null,
    photo: null,
    signature: null
  });
  
  // Form data will be stored here before payment
  const [formDataForPayment, setFormDataForPayment] = useState<PersonalInfoValues | null>(null);

  const form = useForm<PersonalInfoValues>({
    resolver: zodResolver(personalInfoSchema),
    defaultValues: {
      title: "Shri",
      fullName: "",
      relationship: "none",
      parentNameChoice: "none",
      fatherName: "",
      motherName: "",
      guardianName: "",
      email: "",
      phoneNumber: "",
      dateOfBirth: "",
      gender: "male",
      // Citizenship info
      residencyStatus: "none",
      nationality: "Indian",
      // Indian ID documents
      aadhaarNumber: "",
      panNumber: "",
      // NRI specific fields
      passportNumber: "",
      countryOfResidence: "",
      overseasAddress: "",
      address: {
        addressType: "none",
        // Urban fields
        houseNo: "",
        area: "",
        locality: "",
        city: "",
        // Rural fields
        village: "",
        postOffice: "",
        tehsil: "",
        district: "",
        // Common fields
        street: "",
        state: "",
        zipCode: "",
      },
      emergencyContact: {
        name: "",
        relationship: "",
        phoneNumber: "",
      },
      idProofFilename: "",
      photoFilename: "",
      signature: "",
    },
  });

  // Mutation for submitting the full application
  const submitMutation = useMutation({
    mutationFn: async (data: PersonalInfoValues) => {
      return apiRequest("POST", "/api/employees", data);
    },
    onSuccess: () => {
      setShowSuccessMessage(true);
      toast({
        title: "Success!",
        description: "Your application has been submitted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit application",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for saving draft applications
  const saveDraftMutation = useMutation({
    mutationFn: async (data: Partial<PersonalInfoValues>) => {
      return apiRequest("POST", "/api/save-draft", data);
    },
    onSuccess: () => {
      toast({
        title: "Draft Saved",
        description: "Your application progress has been saved. You can return later to complete it.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save draft",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for loading draft applications
  const loadDraftMutation = useMutation({
    mutationFn: async (email: string) => {
      return apiRequest("GET", `/api/drafts/${email}`);
    },
    onSuccess: (response: any) => {
      const draftData = response;
      if (draftData) {
        // We need to format the data properly because some fields may be null
        form.reset({
          ...draftData,
          residencyStatus: draftData.residencyStatus || "none",
          address: {
            ...draftData.address,
            addressType: draftData.address?.addressType || "none"
          },
          emergencyContact: draftData.emergencyContact || {
            name: "",
            relationship: "",
            phoneNumber: ""
          }
        });
        toast({
          title: "Draft Loaded",
          description: "Your saved application has been loaded.",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "No saved draft found",
        variant: "destructive",
      });
    },
  });
  
  // Function to save draft application
  function saveDraft() {
    const formData = form.getValues();
    saveDraftMutation.mutate(formData);
  }
  
  // Function to load draft application
  function loadDraft() {
    const email = form.getValues().email;
    if (!email) {
      toast({
        title: "Email Required",
        description: "Please enter your email address to load your saved application.",
        variant: "destructive",
      });
      return;
    }
    loadDraftMutation.mutate(email);
  }

  function clearSignature() {
    if (signatureRef.current) {
      signatureRef.current.clear();
      form.setValue('signature', '');
    }
  }

  function saveSignature() {
    if (signatureRef.current && !signatureRef.current.isEmpty()) {
      // Convert signature to base64 string
      const signatureData = signatureRef.current.toDataURL();
      form.setValue('signature', signatureData);
    } else {
      toast({
        title: "Signature Required",
        description: "Please sign before submitting the form",
        variant: "destructive",
      });
    }
  }

  function onSubmit(data: PersonalInfoValues) {
    // We don't need the signature canvas check anymore as we're using file upload
    // Just ensure the signature field has the filename
    
    console.log("Form submission data:", data);
    
    // Store form data and show payment modal
    setFormDataForPayment(data);
    setShowPaymentModal(true);
  }
  
  // Handle payment success
  function handlePaymentSuccess() {
    // After successful payment, submit the form data
    if (formDataForPayment) {
      submitMutation.mutate(formDataForPayment);
    }
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>, fileType: 'idProof' | 'photo' | 'signature') {
    const files = e.target.files;
    if (files && files.length > 0) {
      setUploadedFiles(prev => ({
        ...prev,
        [fileType]: files[0]
      }));
      
      // If it's a signature upload, set the signature field to the file name
      if (fileType === 'signature') {
        form.setValue('signature', files[0].name);
      }
    }
  }

  function handleReset() {
    form.reset();
    setShowSuccessMessage(false);
    setUploadedFiles({
      idProof: null,
      photo: null,
      signature: null
    });
  }

  if (showSuccessMessage) {
    return (
      <div className="max-w-3xl mx-auto">
        <div className="flex w-full justify-end mb-4">
          <div className="bg-blue-50 py-2 px-4 rounded-full flex items-center text-blue-700 border border-blue-100 shadow-sm">
            <Phone className="h-4 w-4 mr-2" />
            <span className="text-sm font-medium">24/7 Helpline: <a href="tel:+918249707028" className="hover:underline">+91 8249707028</a></span>
          </div>
        </div>
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-blue-50 p-10 text-center">
          <div className="flex justify-center mb-8">
            <div className="h-24 w-24 bg-gradient-to-r from-green-50 to-green-100 rounded-full flex items-center justify-center shadow-inner">
              <svg className="h-12 w-12 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
          
          <h2 className="text-2xl font-bold text-gray-900 mb-3">PAN Card Application Submitted!</h2>
          <div className="max-w-md mx-auto">
            <p className="text-gray-600 mb-6 text-lg">Your application has been received. Thank you for completing the PAN card application process.</p>
            <p className="text-sm text-gray-500 mb-8">A confirmation has been sent to your email address. You can track your application status using the reference number provided in the email.</p>
          </div>
          
          <Button 
            onClick={() => onComplete()} 
            size="lg"
            variant="default"
            className="mt-4 px-8 py-6 bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900 text-white font-semibold text-lg rounded-xl shadow-lg transform transition-transform duration-200 hover:scale-[1.01]">
            Done
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
        
        {/* Footer */}
        <div className="mt-8 py-6 bg-gray-50 rounded-lg border border-gray-100 text-center">
          <p className="text-gray-600 text-sm">
            For assistance, contact us at: <span className="font-semibold">aazaaad28@gmail.com</span> | <span className="font-semibold">+91 8249707028</span>
          </p>
          <p className="text-gray-500 text-xs mt-2">
            © {new Date().getFullYear()} PAN Card Application Portal. All rights reserved.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
        <div className="p-8 sm:p-10">
          <div className="flex flex-col items-center justify-center mb-8">
            <div className="flex w-full justify-end mb-4">
              <div className="bg-blue-50 py-2 px-4 rounded-full flex items-center text-blue-700 border border-blue-100 shadow-sm">
                <Phone className="h-4 w-4 mr-2" />
                <span className="text-sm font-medium">24/7 Helpline: <a href="tel:+918249707028" className="hover:underline">+91 8249707028</a></span>
              </div>
            </div>
            <div className="text-center">
              <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-blue-800 mb-2">Apply New PAN Card</h1>
              <p className="text-gray-600">Complete the form below to apply for your PAN card</p>
            </div>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Form fields go here */}
              {/* Personal Information Section */}
              <div className="space-y-4">
                <div className="mb-4">
                  <h2 className="text-xl font-bold text-gray-900 pb-2">Personal Details</h2>
                  <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-blue-700 rounded"></div>
                </div>
                
                {/* Title and Full Name in one row */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Title <span className="text-red-500">*</span>
                        </FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="w-full px-4 py-2.5 rounded-lg transition-all duration-200">
                              <SelectValue placeholder="Select title" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Shri">Shri</SelectItem>
                            <SelectItem value="Smt">Smt</SelectItem>
                            <SelectItem value="Kumari">Kumari</SelectItem>
                            <SelectItem value="Miss">Miss</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="sm:col-span-3">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Full Name <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Enter your name as per Aadhaar card" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                {/* Relationship Selection */}
                <FormField
                  control={form.control}
                  name="relationship"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Relationship <span className="text-red-500">*</span>
                      </FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="w-full px-4 py-2.5 rounded-lg transition-all duration-200">
                            <SelectValue placeholder="Select relationship" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">-- Select Relationship --</SelectItem>
                          <SelectItem value="S/O">Son of (S/O)</SelectItem>
                          <SelectItem value="D/O">Daughter of (D/O)</SelectItem>
                          <SelectItem value="C/O">Care of (C/O)</SelectItem>
                          <SelectItem value="W/O">Wife of (W/O)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Parent Name Options */}
                <div className="space-y-4">
                  {/* Parent Name Selection */}
                  <FormField
                    control={form.control}
                    name="parentNameChoice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Choose Parent Name to Provide <span className="text-red-500">*</span>
                        </FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value || "none"}>
                          <FormControl>
                            <SelectTrigger className="w-full px-4 py-2.5 rounded-lg transition-all duration-200">
                              <SelectValue placeholder="Select parent name option" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">-- Select Option --</SelectItem>
                            <SelectItem value="father">Father's Name</SelectItem>
                            <SelectItem value="mother">Mother's Name</SelectItem>
                            <SelectItem value="guardian">Guardian's Name</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Father's Name */}
                  {form.watch('parentNameChoice') === 'father' && (
                    <FormField
                      control={form.control}
                      name="fatherName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Father's Name <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Enter father's name" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  
                  {/* Mother's Name */}
                  {form.watch('parentNameChoice') === 'mother' && (
                    <FormField
                      control={form.control}
                      name="motherName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Mother's Name <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Enter mother's name" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  
                  {/* Guardian's Name */}
                  {form.watch('parentNameChoice') === 'guardian' && (
                    <FormField
                      control={form.control}
                      name="guardianName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Guardian's Name <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Enter guardian's name" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                </div>
                
                {/* Contact Info (Email, Phone) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Email Address <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <div>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Enter your email address" 
                              {...field} 
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phoneNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Phone Number <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <div>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Enter your phone number" 
                              {...field}
                              onChange={(e) => {
                                const formattedValue = formatPhoneNumber(e.target.value);
                                field.onChange(formattedValue);
                              }}
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                {/* DOB and Gender */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                  <FormField
                    control={form.control}
                    name="dateOfBirth"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Date of Birth <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <div>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              type="date" 
                              {...field} 
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="gender"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Gender <span className="text-red-500">*</span>
                        </FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="w-full px-4 py-2.5 rounded-lg transition-all duration-200">
                              <SelectValue placeholder="Select gender" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="male">Male</SelectItem>
                            <SelectItem value="female">Female</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              {/* Citizenship Information */}
              <div className="space-y-4">
                <div className="mb-4">
                  <h2 className="text-xl font-bold text-gray-900 pb-2">Citizenship Information</h2>
                  <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-blue-700 rounded"></div>
                </div>
                
                <FormField
                  control={form.control}
                  name="residencyStatus"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Residency Status <span className="text-red-500">*</span>
                      </FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="w-full px-4 py-2.5 rounded-lg transition-all duration-200">
                            <SelectValue placeholder="Select residency status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">-- Select Residency Status --</SelectItem>
                          <SelectItem value="indian_citizen">Indian Citizen</SelectItem>
                          <SelectItem value="nri">Non-Resident Indian (NRI)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="nationality"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Nationality <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input 
                          className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                          placeholder="Indian" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Conditional fields based on residency status */}
                {form.watch('residencyStatus') === 'indian_citizen' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    <FormField
                      control={form.control}
                      name="aadhaarNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Aadhaar Number <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="1234 5678 9012" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="panNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Existing PAN (if any)
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="ABCDE1234F" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}
                
                {form.watch('residencyStatus') === 'nri' && (
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="passportNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Passport Number <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="J1234567" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="countryOfResidence"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Country of Residence <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="United States" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="overseasAddress"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Overseas Address <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Textarea 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Enter your overseas address" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}
              </div>
              
              {/* Address Information */}
              <div className="space-y-4">
                <div className="mb-4">
                  <h2 className="text-xl font-bold text-gray-900 pb-2">
                    {form.watch('residencyStatus') === 'indian_citizen' 
                      ? 'Residential Address' 
                      : form.watch('residencyStatus') === 'nri' 
                        ? 'Indian Address' 
                        : 'Address'}
                  </h2>
                  <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-blue-700 rounded"></div>
                </div>
                
                <FormField
                  control={form.control}
                  name="address.addressType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Address Type <span className="text-red-500">*</span>
                      </FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="w-full px-4 py-2.5 rounded-lg transition-all duration-200">
                            <SelectValue placeholder="Select address type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">-- Select Type --</SelectItem>
                          <SelectItem value="urban">Urban</SelectItem>
                          <SelectItem value="rural">Rural</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Address Type Specific Fields */}
                {form.watch('address.addressType') === 'urban' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="address.houseNo"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">
                              Flat/Door/Block No. <span className="text-red-500">*</span>
                            </FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                                placeholder="Enter your flat/door/block number" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="address.street"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">
                              Street/Road/Lane <span className="text-red-500">*</span>
                            </FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                                placeholder="Enter street name" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="address.area"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">
                              Area/Location <span className="text-red-500">*</span>
                            </FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                                placeholder="Enter your area or location" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="address.locality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">
                              Locality/Landmark
                            </FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                                placeholder="Enter nearby landmark" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="address.city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Town/City <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Enter your city name" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}
                
                {/* Rural Address Fields */}
                {form.watch('address.addressType') === 'rural' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="address.village"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">
                              Village <span className="text-red-500">*</span>
                            </FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                                placeholder="Enter your village name" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="address.postOffice"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">
                              Post Office <span className="text-red-500">*</span>
                            </FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                                placeholder="Enter post office name" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="address.tehsil"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">
                              Tehsil/Taluka <span className="text-red-500">*</span>
                            </FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                                placeholder="Enter tehsil/taluka name" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="address.district"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">
                              District <span className="text-red-500">*</span>
                            </FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                                placeholder="Enter district name" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                )}
                
                {/* Common Address Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="address.state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          State <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="w-full px-4 py-2.5 rounded-lg transition-all duration-200">
                                <SelectValue placeholder="Select state" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {/* States */}
                              <SelectItem value="Andhra Pradesh">Andhra Pradesh</SelectItem>
                              <SelectItem value="Arunachal Pradesh">Arunachal Pradesh</SelectItem>
                              <SelectItem value="Assam">Assam</SelectItem>
                              <SelectItem value="Bihar">Bihar</SelectItem>
                              <SelectItem value="Chhattisgarh">Chhattisgarh</SelectItem>
                              <SelectItem value="Goa">Goa</SelectItem>
                              <SelectItem value="Gujarat">Gujarat</SelectItem>
                              <SelectItem value="Haryana">Haryana</SelectItem>
                              <SelectItem value="Himachal Pradesh">Himachal Pradesh</SelectItem>
                              <SelectItem value="Jharkhand">Jharkhand</SelectItem>
                              <SelectItem value="Karnataka">Karnataka</SelectItem>
                              <SelectItem value="Kerala">Kerala</SelectItem>
                              <SelectItem value="Madhya Pradesh">Madhya Pradesh</SelectItem>
                              <SelectItem value="Maharashtra">Maharashtra</SelectItem>
                              <SelectItem value="Manipur">Manipur</SelectItem>
                              <SelectItem value="Meghalaya">Meghalaya</SelectItem>
                              <SelectItem value="Mizoram">Mizoram</SelectItem>
                              <SelectItem value="Nagaland">Nagaland</SelectItem>
                              <SelectItem value="Odisha">Odisha</SelectItem>
                              <SelectItem value="Punjab">Punjab</SelectItem>
                              <SelectItem value="Rajasthan">Rajasthan</SelectItem>
                              <SelectItem value="Sikkim">Sikkim</SelectItem>
                              <SelectItem value="Tamil Nadu">Tamil Nadu</SelectItem>
                              <SelectItem value="Telangana">Telangana</SelectItem>
                              <SelectItem value="Tripura">Tripura</SelectItem>
                              <SelectItem value="Uttar Pradesh">Uttar Pradesh</SelectItem>
                              <SelectItem value="Uttarakhand">Uttarakhand</SelectItem>
                              <SelectItem value="West Bengal">West Bengal</SelectItem>
                              
                              {/* Union Territories */}
                              <SelectItem value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</SelectItem>
                              <SelectItem value="Chandigarh">Chandigarh</SelectItem>
                              <SelectItem value="Dadra and Nagar Haveli and Daman and Diu">Dadra and Nagar Haveli and Daman and Diu</SelectItem>
                              <SelectItem value="Delhi">Delhi</SelectItem>
                              <SelectItem value="Jammu and Kashmir">Jammu and Kashmir</SelectItem>
                              <SelectItem value="Ladakh">Ladakh</SelectItem>
                              <SelectItem value="Lakshadweep">Lakshadweep</SelectItem>
                              <SelectItem value="Puducherry">Puducherry</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="address.zipCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Postal/ZIP Code <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input 
                            className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="Enter 6-digit pincode" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              

              
              {/* Document Upload Section */}
              <div className="space-y-4">
                <div className="mb-4">
                  <h2 className="text-xl font-bold text-gray-900 pb-2">Upload Documents</h2>
                  <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-blue-700 rounded"></div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* ID Proof Upload */}
                  <div className="rounded-lg border border-gray-200 p-4 space-y-2 bg-gradient-to-r from-blue-50 to-indigo-50">
                    <h3 className="font-semibold text-blue-900">ID Proof</h3>
                    <p className="text-xs text-blue-700">Upload Aadhaar Card, Voter ID, Passport, or Driving License</p>
                    <div className="mt-2">
                      <input
                        type="file"
                        id="idProof"
                        className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-100 file:text-blue-700 hover:file:bg-blue-200"
                        accept=".jpg,.jpeg,.png,.pdf"
                        onChange={(e) => handleFileChange(e, 'idProof')}
                      />
                    </div>
                    {uploadedFiles.idProof && (
                      <p className="text-xs text-green-700 truncate">
                        Selected: {uploadedFiles.idProof.name}
                      </p>
                    )}
                  </div>
                  
                  {/* Photo Upload */}
                  <div className="rounded-lg border border-gray-200 p-4 space-y-2 bg-gradient-to-r from-green-50 to-teal-50">
                    <h3 className="font-semibold text-green-900">Passport Photo</h3>
                    <p className="text-xs text-green-700">Upload a recent passport size photo (white background)</p>
                    <div className="mt-2">
                      <input
                        type="file"
                        id="photo"
                        className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-green-100 file:text-green-700 hover:file:bg-green-200"
                        accept=".jpg,.jpeg,.png"
                        onChange={(e) => handleFileChange(e, 'photo')}
                      />
                    </div>
                    {uploadedFiles.photo && (
                      <p className="text-xs text-green-700 truncate">
                        Selected: {uploadedFiles.photo.name}
                      </p>
                    )}
                  </div>
                  
                  {/* Signature Upload */}
                  <div className="rounded-lg border border-gray-200 p-4 space-y-2 bg-gradient-to-r from-purple-50 to-pink-50">
                    <h3 className="font-semibold text-purple-900">Signature</h3>
                    <p className="text-xs text-purple-700">Upload scanned copy of your signature</p>
                    <div className="mt-2">
                      <input
                        type="file"
                        id="signature"
                        className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-100 file:text-purple-700 hover:file:bg-purple-200"
                        accept=".jpg,.jpeg,.png"
                        onChange={(e) => handleFileChange(e, 'signature')}
                      />
                    </div>
                    {uploadedFiles.signature && (
                      <p className="text-xs text-green-700 truncate">
                        Selected: {uploadedFiles.signature.name}
                      </p>
                    )}
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-2">Files must be less than 2MB in JPG, PNG or PDF format</p>
              </div>

              {/* Payment Information Section */}
              <div className="space-y-4 mt-8">
                <div className="mb-4">
                  <h2 className="text-xl font-bold text-gray-900 pb-2">Payment Information</h2>
                  <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-blue-700 rounded"></div>
                </div>
                
                <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-1">
                      <svg className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h3 className="text-lg font-medium text-blue-900">Payment Details</h3>
                      <div className="mt-2 space-y-4">
                        <p className="text-sm text-blue-800">A payment of <span className="font-bold">₹199.00</span> is required to submit your PAN card application.</p>
                        
                        <div className="bg-white rounded-lg p-4 border border-blue-200">
                          <h4 className="font-medium text-blue-900 mb-2">Available Payment Methods:</h4>
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
                            <div className="flex items-center space-x-2">
                              <CreditCard className="h-4 w-4 text-blue-600" />
                              <span>Credit/Debit Cards</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Smartphone className="h-4 w-4 text-blue-600" />
                              <span>UPI Payment</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <QrCode className="h-4 w-4 text-blue-600" />
                              <span>QR Code</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-xs text-blue-700">
                          <p>Supported UPI Apps: Google Pay, PhonePe, Paytm, BHIM UPI</p>
                          <p className="mt-1">All payments are secure and processed through Razorpay</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Save Draft & Submit Buttons */}
              <div className="pt-8">
                <div className="flex flex-col sm:flex-row justify-between gap-4">
                  <div className="flex gap-4">
                    <Button 
                      type="button" 
                      variant="outline"
                      className="px-6 py-3 border-blue-300 text-blue-700 font-medium rounded-xl shadow-sm transition-transform duration-200 hover:scale-[1.01] flex items-center justify-center flex-1"
                      onClick={saveDraft}
                      disabled={saveDraftMutation.isPending}
                    >
                      {saveDraftMutation.isPending ? (
                        <span className="flex items-center">Saving...<span className="ml-2 animate-spin">⟳</span></span>
                      ) : (
                        <span className="flex items-center">Save Progress</span>
                      )}
                    </Button>
                    
                    <Button 
                      type="button" 
                      variant="outline"
                      className="px-6 py-3 border-blue-300 text-blue-700 font-medium rounded-xl shadow-sm transition-transform duration-200 hover:scale-[1.01] flex items-center justify-center flex-1"
                      onClick={loadDraft}
                      disabled={loadDraftMutation.isPending}
                    >
                      {loadDraftMutation.isPending ? (
                        <span className="flex items-center">Loading...<span className="ml-2 animate-spin">⟳</span></span>
                      ) : (
                        <span className="flex items-center">Load Saved Application</span>
                      )}
                    </Button>
                  </div>
                  
                  <Button 
                    type="submit" 
                    size="lg"
                    variant="default"
                    className="px-6 py-6 bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900 text-white font-medium text-lg rounded-xl shadow-lg transform transition-transform duration-200 hover:scale-[1.01] flex items-center justify-center flex-1 sm:max-w-md"
                    disabled={submitMutation.isPending}
                  >
                    {submitMutation.isPending ? (
                      <span className="flex items-center">Submitting...<span className="ml-2 animate-spin">⟳</span></span>
                    ) : (
                      <span className="flex items-center">Submit PAN Card Application <ArrowRight className="ml-2 h-5 w-5" /></span>
                    )}
                  </Button>
                </div>
                <p className="text-center text-gray-500 text-sm mt-4">
                  Click "Save Progress" to save your application data for later. You can complete it anytime.
                </p>
              </div>
            </form>
          </Form>
        </div>
      </div>
      
      {/* Payment Modal */}
      {formDataForPayment && (
        <RazorpayScript>
          <PaymentModal
            open={showPaymentModal}
            onOpenChange={setShowPaymentModal}
            onSuccess={handlePaymentSuccess}
            customerName={formDataForPayment.fullName}
            customerEmail={formDataForPayment.email}
            customerPhone={formDataForPayment.phoneNumber}
          />
        </RazorpayScript>
      )}
      {/* Footer */}
      <div className="mt-8 py-6 bg-gray-50 rounded-lg border border-gray-100 text-center">
        <p className="text-gray-600 text-sm">
          For assistance, contact us at: <span className="font-semibold">aazaaad28@gmail.com</span> | <span className="font-semibold">+91 8249707028</span>
        </p>
        <p className="text-gray-500 text-xs mt-2">
          © {new Date().getFullYear()} PAN Card Application Portal. All rights reserved.
        </p>
      </div>
    </div>
  );
}
