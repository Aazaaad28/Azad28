import { InfoIcon } from "lucide-react";

export default function FormHelp() {
  return (
    <div className="mt-6 bg-blue-50 rounded-xl p-4 border border-blue-100 flex items-start">
      <div className="text-blue-500 mr-3 mt-0.5">
        <InfoIcon className="h-5 w-5" />
      </div>
      <div>
        <h3 className="font-medium text-blue-800">Need Help?</h3>
        <p className="text-sm text-blue-700 mt-1">
          If you have any questions or need assistance completing this form, please contact HR at 
          <a href="mailto:hr@example.com" className="underline hover:text-blue-800 ml-1">
            hr@example.com
          </a> or call 
          <a href="tel:+11234567890" className="underline hover:text-blue-800 ml-1">
            (123) 456-7890
          </a>.
        </p>
      </div>
    </div>
  );
}
