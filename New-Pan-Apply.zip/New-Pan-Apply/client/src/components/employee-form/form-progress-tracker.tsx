import { FormStep } from "@/pages/home";
import { useMobile } from "@/hooks/use-mobile";

interface FormProgressTrackerProps {
  currentStep: FormStep;
}

export default function FormProgressTracker({ currentStep }: FormProgressTrackerProps) {
  const isMobile = useMobile();
  
  const getStepProgress = (step: FormStep) => {
    const steps: Record<FormStep, number> = {
      personal: 1,
      employment: 2,
      documentation: 3
    };
    
    return steps[currentStep] >= steps[step] ? "active" : "inactive";
  };
  
  const progressPercentage = () => {
    const steps: Record<FormStep, number> = {
      personal: 33.3,
      employment: 66.6,
      documentation: 100
    };
    
    return `${steps[currentStep]}%`;
  };

  return (
    <div className="mb-6 px-2">
      <div className="flex items-center justify-between">
        <div className={`progress-step progress-step-${getStepProgress("personal")}`}>
          <span className="progress-step-number">1</span>
          <span className="progress-step-text">Personal Information</span>
        </div>
        
        {!isMobile && (
          <>
            <div className="flex items-center">
              <div className="progress-connector"></div>
              <div className={`progress-step progress-step-${getStepProgress("employment")}`}>
                <span className="progress-step-number">2</span>
                <span className="progress-step-text">Employment Details</span>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="progress-connector"></div>
              <div className={`progress-step progress-step-${getStepProgress("documentation")}`}>
                <span className="progress-step-number">3</span>
                <span className="progress-step-text">Documentation</span>
              </div>
            </div>
          </>
        )}
      </div>
      
      <div className="mt-4 h-2 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className="h-full bg-primary rounded-full" 
          style={{ width: progressPercentage() }}
        ></div>
      </div>
    </div>
  );
}
