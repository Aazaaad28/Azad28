import { useState, useRef } from "react";
import SignatureCanvas from "react-signature-canvas";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { personalInfoSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { PaymentModal } from "@/components/payment/payment-modal";
import { RazorpayScript } from "@/components/payment/razorpay-script";
import { formatPhoneNumber } from "@/lib/utils";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { ArrowRight, Mail, Phone, Calendar as CalendarIcon, Briefcase, Building, DollarSign } from "lucide-react";

type PersonalInfoValues = z.infer<typeof personalInfoSchema>;

interface IntegratedFormProps {
  onComplete: () => void;
  isSubmitted: boolean;
}

export default function IntegratedForm({ onComplete, isSubmitted }: IntegratedFormProps) {
  const { toast } = useToast();
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const signatureRef = useRef<SignatureCanvas>(null);
  const [uploadedFiles, setUploadedFiles] = useState<{
    idProof: File | null;
    photo: File | null;
    signature: File | null;
  }>({
    idProof: null,
    photo: null,
    signature: null
  });
  
  // Form data will be stored here before payment
  const [formDataForPayment, setFormDataForPayment] = useState<PersonalInfoValues | null>(null);

  const form = useForm<PersonalInfoValues>({
    resolver: zodResolver(personalInfoSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phoneNumber: "",
      dateOfBirth: "",
      gender: "male",
      // Citizenship info
      residencyStatus: "indian_citizen",
      nationality: "Indian",
      // Indian ID documents
      aadhaarNumber: "",
      panNumber: "",
      // NRI specific fields
      passportNumber: "",
      countryOfResidence: "",
      overseasAddress: "",
      address: {
        addressType: "urban",
        // Urban fields
        houseNo: "",
        area: "",
        locality: "",
        city: "",
        // Rural fields
        village: "",
        postOffice: "",
        tehsil: "",
        district: "",
        // Common fields
        street: "",
        state: "",
        zipCode: "",
      },
      emergencyContact: {
        name: "",
        relationship: "",
        phoneNumber: "",
      },
      jobTitle: "",
      companyName: "",
      startDate: "",
      salary: "",
      idProofFilename: "",
      photoFilename: "",
      signature: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: PersonalInfoValues) => {
      return apiRequest("POST", "/api/employees", data);
    },
    onSuccess: () => {
      setShowSuccessMessage(true);
      toast({
        title: "Success!",
        description: "Your information has been saved.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit form",
        variant: "destructive",
      });
    },
  });

  function clearSignature() {
    if (signatureRef.current) {
      signatureRef.current.clear();
      form.setValue('signature', '');
    }
  }

  function saveSignature() {
    if (signatureRef.current && !signatureRef.current.isEmpty()) {
      // Convert signature to base64 string
      const signatureData = signatureRef.current.toDataURL();
      form.setValue('signature', signatureData);
    } else {
      toast({
        title: "Signature Required",
        description: "Please sign before submitting the form",
        variant: "destructive",
      });
    }
  }

  function onSubmit(data: PersonalInfoValues) {
    // We don't need the signature canvas check anymore as we're using file upload
    // Just ensure the signature field has the filename
    
    console.log("Form submission data:", data);
    
    // Store form data and show payment modal
    setFormDataForPayment(data);
    setShowPaymentModal(true);
  }
  
  // Handle payment success
  function handlePaymentSuccess() {
    // After successful payment, submit the form data
    if (formDataForPayment) {
      mutation.mutate(formDataForPayment);
    }
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>, fileType: 'idProof' | 'photo' | 'signature') {
    const files = e.target.files;
    if (files && files.length > 0) {
      setUploadedFiles(prev => ({
        ...prev,
        [fileType]: files[0]
      }));
      
      // If it's a signature upload, set the signature field to the file name
      if (fileType === 'signature') {
        form.setValue('signature', files[0].name);
      }
    }
  }

  function handleReset() {
    form.reset();
    setShowSuccessMessage(false);
    setUploadedFiles({
      idProof: null,
      photo: null,
      signature: null
    });
  }

  if (showSuccessMessage) {
    return (
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="p-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="h-16 w-16 bg-green-100 rounded-full flex items-center justify-center">
              <svg className="h-8 w-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">PAN Application Submitted!</h2>
          <p className="text-gray-600 mb-6">Your application has been received. Thank you for completing the PAN application process.</p>
          <Button 
            onClick={() => onComplete()} 
            size="lg"
            variant="default"
            className="mt-4 px-6 py-6 bg-blue-600 hover:bg-blue-700 text-white font-medium text-lg">
            Done
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <React.Fragment>
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="p-6 sm:p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold text-gray-900">PAN Application</h1>
            <span className="text-sm text-gray-500 hidden sm:block">All steps in one form</span>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Personal Information Section */}
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-gray-900 border-b pb-2">Personal Details</h2>
              
              {/* Name Fields (First, Last) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        First Name <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input 
                          className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                          placeholder="John" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Last Name <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input 
                          className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                          placeholder="Doe" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Email and Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Email Address <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Mail className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                          <Input 
                            className="pl-10 w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="john.doe@example.com" 
                            type="email"
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="phoneNumber"
                  render={({ field: { onChange, ...rest } }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Phone Number <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Phone className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                          <Input 
                            className="pl-10 w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="(123) 456-7890" 
                            type="tel"
                            onChange={(e) => {
                              const formattedValue = formatPhoneNumber(e.target.value);
                              onChange(formattedValue);
                            }}
                            {...rest}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Date of Birth and Gender */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <FormField
                  control={form.control}
                  name="dateOfBirth"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Date of Birth <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <CalendarIcon className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                          <Input 
                            className="pl-10 w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            type="date" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="gender"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">Gender</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          value={field.value}
                          className="flex space-x-4 pt-2"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="male" id="male" />
                            <label htmlFor="male" className="text-sm font-medium cursor-pointer">Male</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="female" id="female" />
                            <label htmlFor="female" className="text-sm font-medium cursor-pointer">Female</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="other" id="other" />
                            <label htmlFor="other" className="text-sm font-medium cursor-pointer">Other</label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Residency Status and Nationality */}
              <div className="p-4 bg-blue-50 rounded-lg mb-6">
                <h3 className="text-md font-medium text-blue-800 mb-3">Citizenship Information</h3>
                
                <FormField
                  control={form.control}
                  name="residencyStatus"
                  render={({ field }) => (
                    <FormItem className="mb-4">
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Residency Status <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          value={field.value}
                          className="flex space-x-4 pt-2"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="indian_citizen" id="indian_citizen" />
                            <label htmlFor="indian_citizen" className="text-sm font-medium cursor-pointer">Indian Citizen</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="nri" id="nri" />
                            <label htmlFor="nri" className="text-sm font-medium cursor-pointer">Non-Resident Indian (NRI)</label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="nationality"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Nationality <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input 
                            className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="Indian" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {form.watch("residencyStatus") === "nri" && (
                    <FormField
                      control={form.control}
                      name="countryOfResidence"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Country of Residence <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="USA, UK, etc." 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                </div>
              </div>

              {/* Address Type Selector */}
              <FormField
                control={form.control}
                name="address.addressType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-gray-700">
                      Address Type <span className="text-red-500">*</span>
                    </FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        value={field.value}
                        className="flex space-x-4 pt-2"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="urban" id="urban" />
                          <label htmlFor="urban" className="text-sm font-medium cursor-pointer">Urban Area</label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="rural" id="rural" />
                          <label htmlFor="rural" className="text-sm font-medium cursor-pointer">Rural Area</label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Urban Address Fields */}
              {form.watch("address.addressType") === "urban" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="address.houseNo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            House No. <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="123" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="address.area"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Area <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Downtown" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="address.locality"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Locality <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input 
                            className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="East Side" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="address.city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          City <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input 
                            className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="Mumbai" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              )}

              {/* Rural Address Fields */}
              {form.watch("address.addressType") === "rural" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="address.village"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Village <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Village name" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="address.postOffice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Post Office <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Post Office" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="address.tehsil"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            Tehsil <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="Tehsil" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="address.district"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium text-gray-700">
                            District <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input 
                              className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                              placeholder="District" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              )}
              
              {/* Common Address Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="address.state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        State <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input 
                          className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                          placeholder="Maharashtra" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="address.zipCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Pincode <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input 
                          className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                          placeholder="400001" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            {/* ID Documents */}
            <div className="p-4 bg-gray-50 rounded-lg mb-6">
              <h3 className="text-md font-medium text-gray-800 mb-3">Identification Documents</h3>
              
              {/* Conditional ID document fields based on residency status */}
              {form.watch("residencyStatus") === "indian_citizen" ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="aadhaarNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Aadhaar Number <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input 
                            className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="1234 5678 9012" 
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription className="text-xs text-gray-500">
                          Enter your 12-digit Aadhaar number
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="panNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          PAN Number <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input 
                            className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="ABCDE1234F" 
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription className="text-xs text-gray-500">
                          10-character alphanumeric PAN
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              ) : (
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="passportNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Passport Number <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input 
                            className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="J1234567" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="overseasAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-gray-700">
                          Overseas Address <span className="text-red-500">*</span>
                        </FormLabel>
                        <FormControl>
                          <Textarea 
                            className="w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="Your complete overseas address" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              )}
            </div>
            
            {/* Employment Details */}
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-gray-900 border-b pb-2">Employment Details</h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <FormField
                  control={form.control}
                  name="jobTitle"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Job Title
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Briefcase className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                          <Input 
                            className="pl-10 w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="Software Engineer" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="companyName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Company Name
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Building className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                          <Input 
                            className="pl-10 w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            placeholder="Acme Inc." 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Start Date
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <CalendarIcon className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                          <Input 
                            className="pl-10 w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            type="date" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="salary"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Monthly Salary
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <DollarSign className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                          <Input 
                            className="pl-10 w-full px-4 py-2.5 rounded-lg transition-all duration-200"
                            type="number" 
                            placeholder="5000" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {/* Document Upload - Redesigned */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900 border-b pb-2">Required Documents</h2>
                <span className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded-full">All documents are mandatory</span>
              </div>
              
              {/* Document Upload Cards - Modern Design */}
              <div className="space-y-5">
                {/* ID Proof Card */}
                <div className="rounded-xl overflow-hidden border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-300">
                  <div className="flex flex-col md:flex-row">
                    <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 md:w-1/4 flex flex-col justify-center">
                      <div className="flex items-center space-x-3 mb-2">
                        <div className="p-2 bg-white/20 rounded-lg">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                          </svg>
                        </div>
                        <h3 className="font-bold text-lg">ID Proof</h3>
                      </div>
                      <p className="text-white/80 text-sm">Government-issued identity document</p>
                    </div>
                    <div className="p-6 md:flex-1 bg-white">
                      <div className="mb-4">
                        <p className="text-sm text-gray-600 mb-2">
                          <span className="font-medium">Acceptable documents:</span> Aadhaar Card, Voter ID, Driving License, Passport
                        </p>
                        <div className="flex flex-wrap gap-2 mb-3">
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">PDF</span>
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">JPG</span>
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">PNG</span>
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">Max: 5MB</span>
                        </div>
                      </div>
                      <Input 
                        type="file" 
                        accept=".pdf,.jpg,.jpeg,.png" 
                        onChange={(e) => handleFileChange(e, 'idProof')}
                        className="w-full bg-gray-50 border-dashed focus:border-blue-500"
                        required
                      />
                    </div>
                  </div>
                </div>
                
                {/* Passport Photo Card */}
                <div className="rounded-xl overflow-hidden border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-300">
                  <div className="flex flex-col md:flex-row">
                    <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-6 md:w-1/4 flex flex-col justify-center">
                      <div className="flex items-center space-x-3 mb-2">
                        <div className="p-2 bg-white/20 rounded-lg">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <h3 className="font-bold text-lg">Passport Photo</h3>
                      </div>
                      <p className="text-white/80 text-sm">Recent photograph with white background</p>
                    </div>
                    <div className="p-6 md:flex-1 bg-white">
                      <div className="mb-4">
                        <p className="text-sm text-gray-600 mb-2">
                          <span className="font-medium">Requirements:</span> Recent photo, white background, face clearly visible, no hat/sunglasses
                        </p>
                        <div className="flex flex-wrap gap-2 mb-3">
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">JPG</span>
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">PNG</span>
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">Max: 2MB</span>
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">Size: 35mm × 45mm</span>
                        </div>
                      </div>
                      <Input 
                        type="file" 
                        accept="image/*" 
                        onChange={(e) => handleFileChange(e, 'photo')}
                        className="w-full bg-gray-50 border-dashed focus:border-purple-500"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Manual Signature Card */}
                <div className="rounded-xl overflow-hidden border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-300">
                  <div className="flex flex-col md:flex-row">
                    <div className="bg-gradient-to-br from-teal-500 to-teal-600 text-white p-6 md:w-1/4 flex flex-col justify-center">
                      <div className="flex items-center space-x-3 mb-2">
                        <div className="p-2 bg-white/20 rounded-lg">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                          </svg>
                        </div>
                        <h3 className="font-bold text-lg">Signature Upload</h3>
                      </div>
                      <p className="text-white/80 text-sm">Upload a scan of your signature</p>
                    </div>
                    <div className="p-6 md:flex-1 bg-white">
                      <div className="mb-4">
                        <p className="text-sm text-gray-600 mb-2">
                          <span className="font-medium">Requirements:</span> Clear image of your signature on white paper, black ink preferred
                        </p>
                        <div className="flex flex-wrap gap-2 mb-3">
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">JPG</span>
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">PNG</span>
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">Max: 2MB</span>
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">High Contrast</span>
                        </div>
                      </div>
                      <Input 
                        type="file" 
                        accept="image/*" 
                        onChange={(e) => handleFileChange(e, 'signature')}
                        className="w-full bg-gray-50 border-dashed focus:border-teal-500"
                        required
                      />
                      <p className="text-xs text-gray-500 mt-2">Your signature must match the one on your ID documents</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-6">
              <Button 
                type="submit" 
                size="lg"
                variant="default"
                className="w-full px-6 py-6 bg-blue-600 hover:bg-blue-700 text-white font-medium text-lg"
                disabled={mutation.isPending}
              >
                {mutation.isPending ? "Submitting..." : "Submit PAN Application"}
              </Button>
            </div>
            </form>
          </Form>
        </div>
      </div>
      
      {/* Payment Modal */}
      {formDataForPayment && (
        <RazorpayScript>
          <PaymentModal
            open={showPaymentModal}
            onOpenChange={setShowPaymentModal}
            onSuccess={handlePaymentSuccess}
            customerName={`${formDataForPayment.firstName} ${formDataForPayment.lastName}`}
            customerEmail={formDataForPayment.email}
            customerPhone={formDataForPayment.phoneNumber}
          />
        </RazorpayScript>
      )}
    </React.Fragment>);
}
