import { useState } from "react";
import FormProgressTracker from "@/components/employee-form/form-progress-tracker";
import OnboardingForm from "@/components/employee-form/onboarding-form";
import IntegratedForm from "@/components/employee-form/integrated-form";
import FormHelp from "@/components/employee-form/form-help";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export type FormStep = "personal" | "employment" | "documentation";

export default function Home() {
  const [currentStep, setCurrentStep] = useState<FormStep>("personal");
  const [submittedStep, setSubmittedStep] = useState<FormStep | null>(null);
  const { toast } = useToast();

  const handleStepComplete = (step: FormStep) => {
    setSubmittedStep(step);
    
    // Move to next step logic
    if (step === "personal") {
      setCurrentStep("employment");
    } else if (step === "employment") {
      setCurrentStep("documentation");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl w-full mx-auto">
        <IntegratedForm 
          onComplete={() => {
            setSubmittedStep("documentation");
            toast({
              title: "Onboarding Complete!",
              description: "Thank you for completing the onboarding process.",
            });
          }}
          isSubmitted={submittedStep === "documentation"}
        />
        
        <FormHelp />
      </div>
    </div>
  );
}
